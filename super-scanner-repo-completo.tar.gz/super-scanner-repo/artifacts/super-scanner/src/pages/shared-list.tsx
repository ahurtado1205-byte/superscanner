import { useState } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { ShoppingCart, Plus, Loader2, AlertCircle, CheckCircle2, Send, Circle, RotateCcw } from "lucide-react";
import { formatPrice } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface SharedItem {
  id: number;
  name: string;
  brand: string | null;
  price: number | null;
  quantity: string | null;
  units: number;
  checked: boolean;
  notes: string | null;
  createdAt: string;
}

interface SharedList {
  id: number;
  name: string;
  shareToken: string;
  createdAt: string;
  items: SharedItem[];
}

async function fetchSharedList(token: string): Promise<SharedList> {
  const res = await fetch(`/api/lists/shared/${token}`);
  if (!res.ok) throw new Error("Lista no encontrada");
  return res.json();
}

async function addItemToShared(token: string, name: string, notes?: string) {
  const res = await fetch(`/api/lists/shared/${token}/items`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, notes }),
  });
  if (!res.ok) throw new Error("Error al agregar");
  return res.json();
}

async function toggleSharedItem(token: string, itemId: number, checked: boolean) {
  const res = await fetch(`/api/lists/shared/${token}/items/${itemId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ checked }),
  });
  if (!res.ok) throw new Error("Error");
  return res.json();
}

export default function SharedList() {
  const [, params] = useRoute("/shared/:token");
  const token = params?.token ?? "";
  const queryClient = useQueryClient();

  const [itemName, setItemName] = useState("");
  const [itemNotes, setItemNotes] = useState("");
  const [added, setAdded] = useState<string[]>([]);

  const { data, isLoading, error } = useQuery<SharedList>({
    queryKey: ["shared-list", token],
    queryFn: () => fetchSharedList(token),
    refetchInterval: 15000,
  });

  const { mutate: addItem, isPending } = useMutation({
    mutationFn: ({ name, notes }: { name: string; notes: string }) =>
      addItemToShared(token, name, notes),
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries({ queryKey: ["shared-list", token] });
      setAdded((prev) => [vars.name, ...prev]);
      setItemName("");
      setItemNotes("");
    },
  });

  const { mutate: toggleItem } = useMutation({
    mutationFn: ({ id, checked }: { id: number; checked: boolean }) =>
      toggleSharedItem(token, id, checked),
    onMutate: async ({ id, checked }) => {
      await queryClient.cancelQueries({ queryKey: ["shared-list", token] });
      const prev = queryClient.getQueryData<SharedList>(["shared-list", token]);
      if (prev) {
        queryClient.setQueryData<SharedList>(["shared-list", token], {
          ...prev,
          items: prev.items.map((i) => (i.id === id ? { ...i, checked } : i)),
        });
      }
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) queryClient.setQueryData(["shared-list", token], ctx.prev);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["shared-list", token] });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName.trim()) return;
    addItem({ name: itemName.trim(), notes: itemNotes.trim() });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-6 text-center">
        <div>
          <AlertCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Lista no encontrada</h2>
          <p className="text-muted-foreground">El enlace puede haber expirado o ser incorrecto.</p>
        </div>
      </div>
    );
  }

  const unchecked = data.items.filter((i) => !i.checked);
  const checked = data.items.filter((i) => i.checked);
  const sumPrice = (items: SharedItem[]) =>
    items.reduce((s, i) => (i.price == null ? s : s + i.price * i.units), 0);
  const uncheckedTotal = sumPrice(unchecked);
  const checkedTotal = sumPrice(checked);
  const totalAll = uncheckedTotal + checkedTotal;

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* Header */}
      <div className="bg-primary text-primary-foreground px-5 pt-10 pb-6">
        <div className="flex items-center gap-3 mb-1">
          <ShoppingCart className="w-6 h-6 opacity-80" />
          <span className="text-sm font-medium opacity-80">Lista compartida</span>
        </div>
        <h1 className="text-3xl font-bold">{data.name}</h1>
        <p className="text-sm opacity-70 mt-1">
          {format(new Date(data.createdAt), "d 'de' MMMM", { locale: es })} · {data.items.length} {data.items.length === 1 ? "producto" : "productos"}
        </p>
      </div>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">

        {/* Add item form */}
        <div className="bg-card border border-border/50 rounded-2xl p-4 shadow-sm">
          <h2 className="font-bold text-base mb-3">Agregar lo que necesitás</h2>
          <form onSubmit={handleSubmit} className="space-y-3">
            <Input
              placeholder="Ej. Leche descremada, Jabón, Arroz..."
              value={itemName}
              onChange={(e) => setItemName(e.target.value)}
              className="text-base"
              autoComplete="off"
            />
            <Input
              placeholder="Detalle o marca (opcional)"
              value={itemNotes}
              onChange={(e) => setItemNotes(e.target.value)}
              className="text-sm"
            />
            <Button
              type="submit"
              className="w-full rounded-xl h-12 text-base"
              disabled={!itemName.trim() || isPending}
            >
              {isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Agregar a la lista
                </>
              )}
            </Button>
          </form>
        </div>

        {/* Recently added feedback */}
        <AnimatePresence>
          {added.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 text-sm text-green-700 bg-green-50 border border-green-200 rounded-xl px-4 py-3"
            >
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>
                <span className="font-semibold">{added[0]}</span> agregado
                {added.length > 1 && ` y ${added.length - 1} más`}
              </span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Subtotals */}
        {data.items.length > 0 && (uncheckedTotal > 0 || checkedTotal > 0) && (
          <div className="grid grid-cols-3 gap-2 bg-primary/5 border border-primary/20 rounded-2xl p-3">
            <div>
              <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">Por Comprar</p>
              <p className="text-base font-bold">{formatPrice(uncheckedTotal)}</p>
              <p className="text-[10px] text-muted-foreground">{unchecked.length} {unchecked.length === 1 ? "ítem" : "ítems"}</p>
            </div>
            <div>
              <p className="text-[10px] font-semibold text-emerald-700 uppercase tracking-wide">En Carrito</p>
              <p className="text-base font-bold text-emerald-700">{formatPrice(checkedTotal)}</p>
              <p className="text-[10px] text-muted-foreground">{checked.length} {checked.length === 1 ? "ítem" : "ítems"}</p>
            </div>
            <div className="bg-primary text-white rounded-lg p-2">
              <p className="text-[10px] font-semibold uppercase tracking-wide opacity-80">Total</p>
              <p className="text-base font-bold">{formatPrice(totalAll)}</p>
              <p className="text-[10px] opacity-80">{data.items.length} ítems</p>
            </div>
          </div>
        )}

        {/* Pending items */}
        {unchecked.length > 0 && (
          <div>
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3 px-1">
              Por comprar ({unchecked.length}) — Tocá para tachar
            </h3>
            <div className="space-y-2">
              {unchecked.map((item) => (
                <motion.button
                  key={item.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  onClick={() => toggleItem({ id: item.id, checked: true })}
                  className="w-full text-left bg-card border border-border/40 rounded-xl px-4 py-3 flex items-start gap-3 active:bg-primary/5 hover:border-primary/40 transition-all"
                >
                  <Circle className="w-5 h-5 text-muted-foreground/50 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium">{item.name}</p>
                    {item.notes && <p className="text-xs text-muted-foreground mt-0.5">{item.notes}</p>}
                    {item.price != null && (
                      <p className="text-xs font-semibold text-primary mt-1">{formatPrice(item.price * item.units)}{item.units > 1 && ` (${item.units}×)`}</p>
                    )}
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        )}

        {/* Checked items */}
        {checked.length > 0 && (
          <div>
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3 px-1">
              Ya en el carrito ({checked.length})
            </h3>
            <div className="space-y-2">
              {checked.map((item) => (
                <button
                  key={item.id}
                  onClick={() => toggleItem({ id: item.id, checked: false })}
                  className="w-full text-left bg-card border border-border/40 rounded-xl px-4 py-3 flex items-center gap-3 opacity-60 hover:opacity-100 transition-opacity"
                >
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium line-through">{item.name}</p>
                    {item.price != null && (
                      <p className="text-xs text-muted-foreground line-through">{formatPrice(item.price * item.units)}</p>
                    )}
                  </div>
                  <RotateCcw className="w-4 h-4 text-muted-foreground/50" />
                </button>
              ))}
            </div>
          </div>
        )}

        {data.items.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Plus className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>La lista está vacía.</p>
            <p className="text-sm mt-1">Sé el primero en agregar algo.</p>
          </div>
        )}
      </main>
    </div>
  );
}
