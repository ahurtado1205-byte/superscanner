import { useState } from "react";
import { useRoute } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Trash2, Camera, Loader2, Sparkles, AlertCircle, Pencil, Share2, Copy, Check } from "lucide-react";
import { useShoppingList, useAddListItem, useUpdateListItem, useRemoveListItem } from "@/hooks/use-shopping";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { formatPrice, cn } from "@/lib/utils";
import { ScannerOverlay } from "@/components/scanner-overlay";
import type { ScannedProduct } from "@workspace/api-client-react";

export default function ListDetail() {
  const [, params] = useRoute("/list/:id");
  const listId = params?.id ? parseInt(params.id, 10) : 0;

  const { data: listData, isLoading, error } = useShoppingList(listId);
  const { mutate: addItem, isPending: isAdding } = useAddListItem(listId);
  const { mutate: updateItem } = useUpdateListItem(listId);
  const { mutate: removeItem } = useRemoveListItem(listId);

  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isManualAddOpen, setIsManualAddOpen] = useState(false);
  const [manualForm, setManualForm] = useState({ name: "", price: "", quantity: "", units: "1", brand: "" });
  const [editingItem, setEditingItem] = useState<{ id: number; units: number; price: string } | null>(null);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const { mutate: generateShare, isPending: isSharing } = useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/lists/${listId}/share`, { method: "POST" });
      if (!res.ok) throw new Error("Error al generar enlace");
      return res.json() as Promise<{ shareToken: string }>;
    },
    onSuccess: ({ shareToken }) => {
      const base = window.location.origin + import.meta.env.BASE_URL.replace(/\/$/, "");
      setShareUrl(`${base}/shared/${shareToken}`);
      setIsShareOpen(true);
    },
  });

  const handleCopy = () => {
    if (!shareUrl) return;
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleMatchItem = (itemId: number) => {
    updateItem({ id: listId, itemId, data: { checked: true } });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !listData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-6 text-center">
        <div>
          <AlertCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Lista no encontrada</h2>
          <p className="text-muted-foreground mb-6">No pudimos cargar esta lista de compras.</p>
          <Button asChild>
            <a href="/">Volver a Mis Listas</a>
          </Button>
        </div>
      </div>
    );
  }

  const handleManualAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualForm.name.trim()) return;

    addItem({
      id: listId,
      data: {
        name: manualForm.name,
        price: manualForm.price ? parseFloat(manualForm.price) : null,
        quantity: manualForm.quantity || null,
        units: manualForm.units ? parseInt(manualForm.units) : 1,
        brand: manualForm.brand || null,
      }
    }, {
      onSuccess: () => {
        setIsManualAddOpen(false);
        setManualForm({ name: "", price: "", quantity: "", units: "1", brand: "" });
      }
    });
  };

  const handleScannedAdd = (product: ScannedProduct & { units?: number }) => {
    addItem({
      id: listId,
      data: {
        name: product.name,
        price: product.price,
        quantity: product.quantity,
        units: product.units ?? 1,
        brand: product.brand,
        notes: product.notes,
      }
    });
  };

  const toggleCheck = (itemId: number, currentChecked: boolean) => {
    updateItem({ id: listId, itemId, data: { checked: !currentChecked } });
  };

  const pendingItems = listData.items.filter(item => !item.checked);
  const checkedItems = listData.items.filter(item => item.checked);

  const sumPrice = (items: typeof listData.items) =>
    items.reduce((sum, item) => (item.price == null ? sum : sum + item.price * item.units), 0);
  const pendingTotal = sumPrice(pendingItems);
  const checkedTotal = sumPrice(checkedItems);
  const total = pendingTotal + checkedTotal;
  const itemsWithPrice = listData.items.filter(item => item.price != null).length;
  const isPrecompra = (listData as { type?: string }).type === "precompra";

  const handleSaveEdit = () => {
    if (!editingItem) return;
    updateItem({
      id: listId,
      itemId: editingItem.id,
      data: {
        units: editingItem.units,
        price: editingItem.price ? parseFloat(editingItem.price) : null,
      },
    }, { onSuccess: () => setEditingItem(null) });
  };

  return (
    <div className="min-h-screen pb-32 bg-background">
      <PageHeader
        title={listData.name}
        backTo="/"
        action={
          <button
            onClick={() => generateShare()}
            disabled={isSharing}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition-colors text-muted-foreground"
          >
            {isSharing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Share2 className="w-5 h-5" />}
          </button>
        }
      />

      <main className="max-w-3xl mx-auto px-4 md:px-6 py-6">
        
        {/* Empty State */}
        {listData.items.length === 0 && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20 px-4"
          >
            <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Sparkles className="w-10 h-10 text-primary" />
            </div>
            <h3 className="text-2xl font-display font-bold mb-2">Lista Vacía</h3>
            <p className="text-muted-foreground max-w-sm mx-auto mb-8">
              Toca el botón de la cámara abajo para escanear productos en el súper, o añádelos manualmente.
            </p>
            <Button variant="outline" className="rounded-full" onClick={() => setIsManualAddOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Añadir Manualmente
            </Button>
          </motion.div>
        )}

        {/* Subtotals & Total */}
        {listData.items.length > 0 && itemsWithPrice > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`mb-6 rounded-2xl border p-4 ${isPrecompra ? "bg-violet-50 border-violet-200" : "bg-primary/10 border-primary/20"}`}
          >
            <div className="flex items-center justify-between mb-3">
              <p className={`text-xs font-semibold uppercase tracking-wider ${isPrecompra ? "text-violet-700" : "text-primary/70"}`}>
                {isPrecompra ? "Pre-compra" : "Total estimado"}
              </p>
              <p className="text-xs text-muted-foreground">
                {itemsWithPrice} de {listData.items.length} con precio
              </p>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-white/70 rounded-xl p-3">
                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-1">Por Comprar</p>
                <p className="text-lg font-bold text-foreground">{formatPrice(pendingTotal)}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{pendingItems.length} {pendingItems.length === 1 ? "ítem" : "ítems"}</p>
              </div>
              <div className="bg-white/70 rounded-xl p-3">
                <p className="text-[10px] font-semibold text-emerald-700 uppercase tracking-wide mb-1">En Carrito</p>
                <p className="text-lg font-bold text-emerald-700">{formatPrice(checkedTotal)}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{checkedItems.length} {checkedItems.length === 1 ? "ítem" : "ítems"}</p>
              </div>
              <div className={`rounded-xl p-3 ${isPrecompra ? "bg-violet-600 text-white" : "bg-primary text-white"}`}>
                <p className="text-[10px] font-semibold uppercase tracking-wide mb-1 opacity-80">Total</p>
                <p className="text-lg font-bold">{formatPrice(total)}</p>
                <p className="text-[10px] mt-0.5 opacity-80">{listData.items.length} {listData.items.length === 1 ? "ítem" : "ítems"}</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Pending Items */}
        {pendingItems.length > 0 && (
          <div className="mb-10">
            <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-4 px-1">
              Por Comprar ({pendingItems.length})
            </h3>
            <div className="space-y-3">
              <AnimatePresence>
                {pendingItems.map((item) => (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9, x: -20 }}
                    className="group bg-card rounded-2xl p-4 shadow-sm border border-border/50 flex gap-4 items-center"
                  >
                    <button 
                      onClick={() => toggleCheck(item.id, item.checked)}
                      className={cn(
                        "flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all",
                        "border-2 border-muted-foreground/30 hover:border-primary"
                      )}
                    />
                    
                    <div className="flex-grow min-w-0">
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          {item.units > 1 && (
                            <span className="shrink-0 bg-primary text-primary-foreground text-xs font-bold px-2 py-0.5 rounded-full">
                              x{item.units}
                            </span>
                          )}
                          <h4 className="font-bold text-lg text-foreground truncate">{item.name}</h4>
                        </div>
                        {item.price != null && (
                          <span className="font-bold text-primary whitespace-nowrap">
                            {formatPrice(item.price)}
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-2 mt-1 text-sm text-muted-foreground">
                        {item.brand && <span>{item.brand}</span>}
                        {item.brand && item.quantity && <span>•</span>}
                        {item.quantity && <span>{item.quantity}</span>}
                      </div>
                    </div>

                    <div className="flex gap-1 flex-shrink-0">
                      <button
                        onClick={() => setEditingItem({ id: item.id, units: item.units, price: item.price != null ? String(item.price) : "" })}
                        className="p-2 text-muted-foreground/50 hover:text-primary hover:bg-primary/10 rounded-full transition-colors"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => removeItem({ id: listId, itemId: item.id })}
                        className="p-2 text-muted-foreground/50 hover:text-destructive hover:bg-destructive/10 rounded-full transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}

        {/* Checked Items */}
        {checkedItems.length > 0 && (
          <div>
            <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-4 px-1">
              En el Carrito ({checkedItems.length})
            </h3>
            <div className="space-y-3 opacity-60">
              <AnimatePresence>
                {checkedItems.map((item) => (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9, x: 20 }}
                    className="bg-card/50 rounded-2xl p-4 border border-border/30 flex gap-4 items-center grayscale-[0.5]"
                  >
                    <button 
                      onClick={() => toggleCheck(item.id, item.checked)}
                      className="flex-shrink-0 w-8 h-8 rounded-full bg-primary border-primary text-primary-foreground flex items-center justify-center"
                    >
                      <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                    </button>
                    
                    <div className="flex-grow min-w-0">
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          {item.units > 1 && (
                            <span className="shrink-0 bg-muted text-muted-foreground text-xs font-bold px-2 py-0.5 rounded-full">
                              x{item.units}
                            </span>
                          )}
                          <h4 className="font-bold text-lg text-foreground line-through decoration-2 decoration-foreground/30 truncate">{item.name}</h4>
                        </div>
                        {item.price != null && (
                          <span className="font-bold text-foreground/70 whitespace-nowrap">
                            {formatPrice(item.price)}
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-2 mt-1 text-sm text-muted-foreground">
                        {item.brand && <span>{item.brand}</span>}
                        {item.brand && item.quantity && <span>•</span>}
                        {item.quantity && <span>{item.quantity}</span>}
                      </div>
                    </div>

                    <button 
                      onClick={() => removeItem({ id: listId, itemId: item.id })}
                      className="p-2 text-muted-foreground/50 hover:text-destructive hover:bg-destructive/10 rounded-full transition-colors flex-shrink-0"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}
      </main>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 left-0 right-0 z-40 flex justify-center px-6 gap-4">
        <Button 
          size="fab" 
          variant="secondary"
          className="shadow-xl bg-white text-primary border border-border"
          onClick={() => setIsManualAddOpen(true)}
        >
          <Plus className="w-7 h-7" />
        </Button>
        <Button 
          className="h-16 px-8 rounded-full shadow-2xl shadow-primary/40 hover:scale-105 active:scale-95 text-lg"
          onClick={() => setIsScannerOpen(true)}
        >
          <Camera className="w-6 h-6 mr-3" />
          Escanear Producto
        </Button>
      </div>

      {/* Manual Add Dialog */}
      <Dialog open={isManualAddOpen} onOpenChange={setIsManualAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Añadir Producto</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleManualAdd} className="space-y-4 pt-4">
            <div>
              <label className="text-sm font-semibold mb-1.5 block">Nombre del Producto *</label>
              <Input
                placeholder="Ej. Leche descremada"
                value={manualForm.name}
                onChange={(e) => setManualForm({...manualForm, name: e.target.value})}
                autoFocus
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-sm font-semibold mb-1.5 block">Unidades</label>
                <Input
                  type="number"
                  min="1"
                  placeholder="1"
                  value={manualForm.units}
                  onChange={(e) => setManualForm({...manualForm, units: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm font-semibold mb-1.5 block">Precio ($)</label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={manualForm.price}
                  onChange={(e) => setManualForm({...manualForm, price: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm font-semibold mb-1.5 block">Peso/Vol.</label>
                <Input
                  placeholder="1L, 500g"
                  value={manualForm.quantity}
                  onChange={(e) => setManualForm({...manualForm, quantity: e.target.value})}
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-semibold mb-1.5 block">Marca</label>
              <Input
                placeholder="Opcional"
                value={manualForm.brand}
                onChange={(e) => setManualForm({...manualForm, brand: e.target.value})}
              />
            </div>
            <DialogFooter className="pt-4">
              <Button type="button" variant="ghost" onClick={() => setIsManualAddOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={!manualForm.name.trim() || isAdding}>
                {isAdding ? <Loader2 className="w-5 h-5 animate-spin" /> : "Guardar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Item Dialog */}
      <Dialog open={!!editingItem} onOpenChange={(open) => !open && setEditingItem(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Producto</DialogTitle>
          </DialogHeader>
          {editingItem && (
            <div className="space-y-5 pt-2">
              <div>
                <label className="text-sm font-semibold mb-2 block">Cantidad de unidades</label>
                <div className="flex items-center gap-4">
                  <button
                    type="button"
                    onClick={() => setEditingItem(e => e ? { ...e, units: Math.max(1, e.units - 1) } : e)}
                    className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-2xl font-bold hover:bg-muted/70 active:scale-95 transition-all"
                  >
                    −
                  </button>
                  <span className="flex-1 text-center text-3xl font-bold tabular-nums">{editingItem.units}</span>
                  <button
                    type="button"
                    onClick={() => setEditingItem(e => e ? { ...e, units: e.units + 1 } : e)}
                    className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-2xl font-bold text-primary-foreground hover:bg-primary/90 active:scale-95 transition-all"
                  >
                    +
                  </button>
                </div>
              </div>
              <div>
                <label className="text-sm font-semibold mb-1.5 block">Precio ($)</label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={editingItem.price}
                  onChange={(e) => setEditingItem(ei => ei ? { ...ei, price: e.target.value } : ei)}
                />
              </div>
            </div>
          )}
          <DialogFooter className="pt-4">
            <Button type="button" variant="ghost" onClick={() => setEditingItem(null)}>Cancelar</Button>
            <Button onClick={handleSaveEdit}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Share Dialog */}
      <Dialog open={isShareOpen} onOpenChange={setIsShareOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Compartir lista</DialogTitle>
            <DialogDescription>
              Mandá este enlace a tu familia para que agreguen lo que necesitan. Cualquiera con el link puede ver y agregar productos.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="bg-muted rounded-xl px-3 py-2.5 flex items-center gap-2">
              <span className="text-sm text-muted-foreground flex-1 truncate">{shareUrl}</span>
            </div>
            <Button className="w-full gap-2" onClick={handleCopy}>
              {copied ? <><Check className="w-4 h-4" /> ¡Copiado!</> : <><Copy className="w-4 h-4" /> Copiar enlace</>}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Fullscreen Scanner Overlay */}
      <ScannerOverlay 
        isOpen={isScannerOpen} 
        onClose={() => setIsScannerOpen(false)} 
        onAddProduct={handleScannedAdd}
        onMatchItem={handleMatchItem}
        uncheckedItems={pendingItems.map(i => ({ id: i.id, name: i.name }))}
      />
    </div>
  );
}
