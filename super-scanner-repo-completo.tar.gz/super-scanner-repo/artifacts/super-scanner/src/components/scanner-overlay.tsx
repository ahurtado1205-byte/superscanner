import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, X, Sparkles, AlertCircle, CheckCircle2, ImageUp, ListChecks } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { fileToBase64 } from "@/lib/utils";
import { useScanner } from "@/hooks/use-scanner";
import type { ScannedProduct } from "@workspace/api-client-react";

interface UncheckedItem {
  id: number;
  name: string;
}

interface ScannerOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onAddProduct: (product: ScannedProduct & { units: number }) => void;
  onMatchItem?: (itemId: number) => void;
  uncheckedItems?: UncheckedItem[];
}

function normalize(s: string) {
  return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9 ]/g, "").trim();
}

function findMatch(scannedName: string, items: UncheckedItem[]): UncheckedItem | null {
  const scanned = normalize(scannedName);
  const scannedWords = scanned.split(" ").filter((w) => w.length > 2);

  let best: { item: UncheckedItem; score: number } | null = null;

  for (const item of items) {
    const norm = normalize(item.name);
    if (scanned.includes(norm) || norm.includes(scanned)) {
      return item; // exact substring match
    }
    const itemWords = norm.split(" ").filter((w) => w.length > 2);
    const shared = scannedWords.filter((w) => itemWords.some((iw) => iw.includes(w) || w.includes(iw)));
    const score = shared.length / Math.max(scannedWords.length, itemWords.length, 1);
    if (score >= 0.5 && (!best || score > best.score)) {
      best = { item, score };
    }
  }
  return best?.item ?? null;
}

export function ScannerOverlay({ isOpen, onClose, onAddProduct, onMatchItem, uncheckedItems = [] }: ScannerOverlayProps) {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [scannedData, setScannedData] = useState<ScannedProduct | null>(null);
  const [units, setUnits] = useState<number>(1);
  const [error, setError] = useState<string | null>(null);
  const [matchedItem, setMatchedItem] = useState<UncheckedItem | null>(null);

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const { mutateAsync: scanLabel } = useScanner();

  const resetState = () => {
    setImageSrc(null);
    setIsAnalyzing(false);
    setScannedData(null);
    setUnits(1);
    setError(null);
    setMatchedItem(null);
    if (cameraInputRef.current) cameraInputRef.current.value = "";
    if (galleryInputRef.current) galleryInputRef.current.value = "";
  };

  const handleClose = () => {
    resetState();
    onClose();
  };

  const processFile = async (file: File) => {
    try {
      setError(null);
      setIsAnalyzing(true);
      setMatchedItem(null);

      const base64 = await fileToBase64(file);
      setImageSrc(base64);

      const result = await scanLabel({ data: { imageBase64: base64 } });
      setScannedData(result);

      if (uncheckedItems.length > 0 && result.name) {
        const match = findMatch(result.name, uncheckedItems);
        setMatchedItem(match);
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Error desconocido";
      console.error(err);
      setError(message || "Error al analizar la imagen. Intenta de nuevo.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processFile(file);
  };

  const handleConfirmMatch = () => {
    if (matchedItem && onMatchItem) {
      onMatchItem(matchedItem.id);
      handleClose();
    }
  };

  const handleIgnoreMatch = () => {
    setMatchedItem(null);
  };

  const handleConfirm = () => {
    if (scannedData) {
      onAddProduct({ ...scannedData, units });
      handleClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: "100%" }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: "100%" }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center overflow-hidden"
        >
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-6 right-6 z-50 rounded-full text-white hover:bg-white/10"
            onClick={handleClose}
          >
            <X className="w-6 h-6" />
          </Button>

          {/* Hidden inputs */}
          <input
            type="file"
            accept="image/*"
            capture="environment"
            ref={cameraInputRef}
            className="hidden"
            onChange={handleFileChange}
          />
          <input
            type="file"
            accept="image/*"
            ref={galleryInputRef}
            className="hidden"
            onChange={handleFileChange}
          />

          {/* Initial state: choose camera or gallery */}
          {!imageSrc && !isAnalyzing && (
            <div className="flex flex-col items-center justify-center p-8 text-center h-full">
              <div className="w-28 h-28 rounded-full bg-primary/20 flex items-center justify-center mb-8">
                <Camera className="w-14 h-14 text-primary" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-3">Escáner de Productos</h2>
              <p className="text-white/60 mb-12 max-w-sm text-base leading-relaxed">
                Tomá una foto de la etiqueta del producto y la IA extrae el nombre, precio y cantidad automáticamente.
              </p>

              <div className="w-full max-w-xs space-y-4">
                <Button
                  size="lg"
                  className="w-full rounded-2xl h-14 text-lg"
                  onClick={() => cameraInputRef.current?.click()}
                >
                  <Camera className="w-5 h-5 mr-3" />
                  Tomar Foto
                </Button>

                <Button
                  size="lg"
                  variant="outline"
                  className="w-full rounded-2xl h-14 text-lg border-white/20 text-white hover:bg-white/10 hover:text-white"
                  onClick={() => galleryInputRef.current?.click()}
                >
                  <ImageUp className="w-5 h-5 mr-3" />
                  Subir desde Galería
                </Button>
              </div>
            </div>
          )}

          {/* Analyzing / result state */}
          {(imageSrc || isAnalyzing) && (
            <div className="relative w-full h-full flex flex-col items-center justify-center p-4">
              {imageSrc && (
                <div className="relative w-full max-w-md aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl bg-black border border-white/10">
                  <img src={imageSrc} alt="Etiqueta escaneada" className="w-full h-full object-cover" />

                  {isAnalyzing && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center">
                      <Sparkles className="w-12 h-12 text-primary animate-bounce mb-4" />
                      <h3 className="text-xl font-bold text-white tracking-wide">Analizando etiqueta...</h3>
                      <p className="text-white/60 mt-2 text-sm">La IA está leyendo el producto</p>
                    </div>
                  )}
                </div>
              )}

              {/* Only analyzing, no image yet */}
              {isAnalyzing && !imageSrc && (
                <div className="flex flex-col items-center">
                  <Sparkles className="w-16 h-16 text-primary animate-bounce mb-6" />
                  <h3 className="text-2xl font-bold text-white">Analizando...</h3>
                </div>
              )}

              {error && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 bg-red-900/80 backdrop-blur-md text-white p-5 rounded-2xl w-full max-w-md shadow-2xl flex items-start gap-4 border border-red-500/30"
                >
                  <AlertCircle className="w-7 h-7 shrink-0 mt-0.5 text-red-300" />
                  <div>
                    <h4 className="font-bold text-base mb-1">No se pudo analizar</h4>
                    <p className="text-white/80 text-sm">{error}</p>
                    <Button
                      variant="secondary"
                      className="mt-4 w-full bg-white text-red-700 hover:bg-white/90"
                      onClick={resetState}
                    >
                      Intentar de nuevo
                    </Button>
                  </div>
                </motion.div>
              )}

              {scannedData && !isAnalyzing && matchedItem && onMatchItem && (
                <motion.div
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute bottom-0 left-0 right-0 p-4 md:p-6 pb-8 bg-background rounded-t-[2.5rem] shadow-2xl"
                >
                  <div className="w-12 h-1.5 bg-muted rounded-full mx-auto mb-5" />
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                      <ListChecks className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-foreground">¡Está en tu lista!</h3>
                      <p className="text-sm text-muted-foreground">Escaneaste: <span className="font-medium">{scannedData.name}</span></p>
                    </div>
                  </div>

                  <div className="bg-primary/10 border border-primary/20 rounded-2xl px-4 py-3 mb-5 flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full bg-primary shrink-0" />
                    <p className="font-bold text-foreground text-lg">{matchedItem.name}</p>
                  </div>

                  <p className="text-sm text-muted-foreground mb-5 text-center">
                    ¿Tachamos este ítem de la lista?
                  </p>

                  <div className="flex gap-3">
                    <Button variant="outline" className="flex-1" onClick={handleIgnoreMatch}>
                      No es este
                    </Button>
                    <Button className="flex-[2] text-base font-semibold bg-green-600 hover:bg-green-700" onClick={handleConfirmMatch}>
                      <CheckCircle2 className="w-5 h-5 mr-2" />
                      ¡Sí, tacharlo!
                    </Button>
                  </div>
                </motion.div>
              )}

              {scannedData && !isAnalyzing && !matchedItem && (
                <motion.div
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute bottom-0 left-0 right-0 p-4 md:p-6 pb-8 bg-background rounded-t-[2.5rem] shadow-2xl max-h-[65vh] overflow-y-auto"
                >
                  <div className="w-12 h-1.5 bg-muted rounded-full mx-auto mb-5" />
                  <div className="flex items-center gap-3 mb-5">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground">¡Producto encontrado!</h3>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">
                        Nombre del producto
                      </label>
                      <Input
                        value={scannedData.name}
                        onChange={(e) => setScannedData({ ...scannedData, name: e.target.value })}
                        className="font-semibold text-base"
                      />
                    </div>

                    {/* Units stepper */}
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">
                        Cantidad de unidades
                      </label>
                      <div className="flex items-center gap-4">
                        <button
                          type="button"
                          onClick={() => setUnits(u => Math.max(1, u - 1))}
                          className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-2xl font-bold text-foreground hover:bg-muted/70 active:scale-95 transition-all"
                        >
                          −
                        </button>
                        <span className="flex-1 text-center text-3xl font-bold text-foreground tabular-nums">
                          {units}
                        </span>
                        <button
                          type="button"
                          onClick={() => setUnits(u => u + 1)}
                          className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-2xl font-bold text-primary-foreground hover:bg-primary/90 active:scale-95 transition-all"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">
                          Precio ($)
                        </label>
                        <Input
                          type="number"
                          value={scannedData.price ?? ""}
                          onChange={(e) =>
                            setScannedData({
                              ...scannedData,
                              price: e.target.value ? parseFloat(e.target.value) : null,
                            })
                          }
                          placeholder="0.00"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">
                          Peso/Vol.
                        </label>
                        <Input
                          value={scannedData.quantity ?? ""}
                          onChange={(e) => setScannedData({ ...scannedData, quantity: e.target.value || null })}
                          placeholder="500g, 1L"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">
                        Marca (opcional)
                      </label>
                      <Input
                        value={scannedData.brand ?? ""}
                        onChange={(e) => setScannedData({ ...scannedData, brand: e.target.value || null })}
                        placeholder="Marca"
                      />
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button variant="outline" className="flex-1" onClick={resetState}>
                      Descartar
                    </Button>
                    <Button className="flex-[2] text-base font-semibold" onClick={handleConfirm}>
                      Añadir a la lista
                    </Button>
                  </div>
                </motion.div>
              )}
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
