import { useQueryClient } from "@tanstack/react-query";
import {
  useGetLists as useGeneratedGetLists,
  useCreateList as useGeneratedCreateList,
  useDeleteList as useGeneratedDeleteList,
  useGetList as useGeneratedGetList,
  useAddItemToList as useGeneratedAddItemToList,
  useUpdateListItem as useGeneratedUpdateListItem,
  useDeleteListItem as useGeneratedDeleteListItem,
  getGetListsQueryKey,
  getGetListQueryKey,
} from "@workspace/api-client-react";

// Wrap generated hooks to add cache invalidation

export function useShoppingLists() {
  return useGeneratedGetLists();
}

export function useCreateShoppingList() {
  const queryClient = useQueryClient();
  return useGeneratedCreateList({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetListsQueryKey() });
      },
    },
  });
}

export function useDeleteShoppingList() {
  const queryClient = useQueryClient();
  return useGeneratedDeleteList({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetListsQueryKey() });
      },
    },
  });
}

export function useShoppingList(id: number) {
  return useGeneratedGetList(id, {
    query: {
      enabled: !isNaN(id) && id > 0,
    },
  });
}

export function useAddListItem(listId: number) {
  const queryClient = useQueryClient();
  return useGeneratedAddItemToList({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetListQueryKey(listId) });
      },
    },
  });
}

export function useUpdateListItem(listId: number) {
  const queryClient = useQueryClient();
  return useGeneratedUpdateListItem({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetListQueryKey(listId) });
      },
    },
  });
}

export function useRemoveListItem(listId: number) {
  const queryClient = useQueryClient();
  return useGeneratedDeleteListItem({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetListQueryKey(listId) });
      },
    },
  });
}
