import { useScanLabel as useGeneratedScanLabel } from "@workspace/api-client-react";

export function useScanner() {
  return useGeneratedScanLabel();
}
