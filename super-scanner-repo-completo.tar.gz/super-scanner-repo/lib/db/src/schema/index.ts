export * from "./shopping";
